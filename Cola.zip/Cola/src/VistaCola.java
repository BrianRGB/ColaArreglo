import javax.swing.*;

public class VistaCola {
    private JPanel pPrincipal;
}
